DROP TABLE member; 

DROP TABLE member_tag; 

DROP TABLE member_region; 

DROP TABLE foret; 

DROP TABLE foret_tag; 

DROP TABLE foret_region; 

DROP TABLE tag; 

DROP TABLE region; 

DROP TABLE foret_member; 

DROP TABLE board; 

DROP TABLE board_comment; 

DROP TABLE like_board; 

DROP TABLE like_comment; 

DROP TABLE member_photo; 

DROP TABLE foret_photo; 

DROP TABLE board_photo; 

-- ������ 
DROP SEQUENCE seq_member_id; 

DROP SEQUENCE seq_foret_id; 

DROP SEQUENCE seq_board_id; 

DROP SEQUENCE seq_tag_id; 

DROP SEQUENCE seq_region_id; 

DROP SEQUENCE seq_member_photo_id; 

DROP SEQUENCE seq_foret_photo_id; 

DROP SEQUENCE seq_board_photo_id; 

DROP SEQUENCE seq_board_comment_id; 